package com.example.pushpak.trackme;

import android.app.ProgressDialog;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public abstract class MainActivity extends AppCompatActivity {
    private EditText Email;
    private EditText Password;
    private TextView Forgot;
    private TextView Register;
    private Button Login;

   // private FirebaseAuth mAuth;
    private DatabaseReference ref;


    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     //   mAuth = FirebaseAuth.getInstance();

        Email = (EditText)findViewById(R.id.etEmail);
        Password = (EditText)findViewById(R.id.etPassword);
        Forgot = (TextView)findViewById(R.id.txtForgotPassword);
        Register = (TextView)findViewById(R.id.txtRegister);
        Login = (Button)findViewById(R.id.btnLogin);

        progressDialog = new ProgressDialog(this);
           ref = FirebaseDatabase.getInstance().getReference().child("user");
        Login.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View view){
                Validate(Email.getText().toString(), Password.getText().toString());
                if(view == Login) {
                    userLogin();
                }
            }
        });
    }
    String pass;
    private void userLogin(){
        String email = Email.getText().toString();
         pass = Password.getText().toString();
         if(ref.child(email) !=null) {
             ref.child(email).addValueEventListener(new ValueEventListener() {
                 @Override
                 public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                     user user = dataSnapshot.getValue(user.class);
                     if (pass.equals(user.getPassword())) {
                         Toast.makeText(MainActivity.this, "Login successfully", Toast.LENGTH_LONG).show();
                         Intent start = new Intent(MainActivity.this, hello.class);
                         startActivity(start);
                     } else {
                         Toast.makeText(MainActivity.this, "Check password", Toast.LENGTH_LONG).show();
                     }
                 }

                 @Override
                 public void onCancelled(@NonNull DatabaseError databaseError) {
                     Toast.makeText(MainActivity.this, "Check login details", Toast.LENGTH_LONG).show();

                 }
             });
         }

    }
    //Login validation for email and password
    private void Validate(String UserEmail, String UserPassword) {
        if ((UserEmail.equals("admin")) && (UserPassword.equals("admin"))) {
            Intent intent = new Intent(MainActivity.this, Register.class);
            //Instead of SecondActivity put the page with map page....
            startActivity(intent);
        }
    }

    public void ForgotPassword_action(View v)
    {
//        TextView tv= (TextView) findViewById(R.id.text_view);
        Forgot = (TextView)findViewById(R.id.txtForgotPassword);
        Intent to_forgot_password = new Intent(MainActivity.this, forgetpassword.class);
        //Instead of ForgotPasswordPage put the page with forgot password....
        startActivity(to_forgot_password);

    }
    public void Register_action(View v)
    {
        Register = (TextView)findViewById(R.id.txtRegister);
        Intent to_register = new Intent(MainActivity.this, Register.class);
        //Instead of Register put the page with sign up....
        startActivity(to_register);

    }



}
