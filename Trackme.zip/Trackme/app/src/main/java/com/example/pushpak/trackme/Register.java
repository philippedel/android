package com.example.pushpak.trackme;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.app.ProgressDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    EditText t1;
    EditText t2;
    EditText ps1;
    EditText p1;
    Button b1;

    String name;
    EditText email;
    EditText password;
    String phone;
    ProgressDialog pDialog;
    //defining firebaseauth object
    private FirebaseAuth firebaseAuth;
    DatabaseReference databasereus;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        databasereus = FirebaseDatabase.getInstance().getReference("reus");
        firebaseAuth= FirebaseAuth.getInstance();

        email = (EditText)findViewById(R.id.t2);
        password = (EditText)findViewById(R.id.ps1);
        Button register = (Button) findViewById(R.id.b1);

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addreus();
                }

                private void addreus() {
                    String name = t1.getText().toString().trim();
                    String phone  = p1.getText().toString().trim();

                    if(!TextUtils.isEmpty(name)){
                        String t1 = databasereus.push().getKey();
                        reus re = new reus(name, phone);
                        databasereus.child(name).setValue(t1);
                    }
                }
            });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {

            public void RegisterUser(){
                String email = t2.getText().toString().trim();
                String password = ps1.getText().toString().trim();

                if(email.isEmpty()){
                    t2.setError("enter email");
                    t2.requestFocus();
                    return;
                }
                if(password.isEmpty()){
                    ps1.setError("enter email");
                    ps1.requestFocus();
                    return;
                }

                firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "registered", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

            }
        });
    }

}
