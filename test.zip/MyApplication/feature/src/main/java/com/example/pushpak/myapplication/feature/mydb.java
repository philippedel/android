package com.example.pushpak.myapplication.feature;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class mydb extends SQLiteOpenHelper {
    public mydb(Context context) {
        super(context, "mydb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String stu ="Create TABLE student(email VARCHAR, pass VARCHAR, code VARCHAR primary key);";
        db.execSQL(stu);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
