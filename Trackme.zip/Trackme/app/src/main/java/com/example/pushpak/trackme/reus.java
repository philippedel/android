package com.example.pushpak.trackme;

public class reus {
    String name;
    String Phone;

    public reus(){

    }

    public reus(String name, String phone) {
        this.name = name;
        Phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return Phone;
    }
}
