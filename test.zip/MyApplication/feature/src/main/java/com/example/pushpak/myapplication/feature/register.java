package com.example.pushpak.myapplication.feature;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void register(View view) {
        EditText email = findViewById(R.id.em);
        EditText pass = findViewById(R.id.ps);
        EditText code = findViewById(R.id.co);

        String ema = email.getText().toString();
        String pas = pass.getText().toString();
        String cd = code.getText().toString();

        mydb db= new mydb(this);
        SQLiteDatabase dbs= db.getWritableDatabase();
        ContentValues val= new ContentValues();
        val.put("email", ema);
        val.put("pass", pas);
        val.put("code", cd);
        dbs.insert("student", null, val);
        Toast.makeText(this, "inserted", Toast.LENGTH_LONG).show();
    }
}
