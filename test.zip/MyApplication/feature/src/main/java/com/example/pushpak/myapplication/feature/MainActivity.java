package com.example.pushpak.myapplication.feature;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void re(View view){
        Intent inte = new Intent(this, register.class);
        startActivity(inte);
    }
    public void lg(View view){
        mydb dbss= new mydb(this);
        SQLiteDatabase dbsss=dbss.getReadableDatabase();
        EditText ema = findViewById(R.id.em);
        EditText pas = findViewById(R.id.ps);
        String[] columns={"email", "pass"};
        String[] cval={ema.getText().toString(), pas.getText().toString()};
        Cursor cu=dbsss.query("student",columns, "email=? AND pass=?", cval, null,null,null);
        if(cu != null){
            if(cu.moveToFirst()){
                Toast.makeText(this, "login Sucessfully",Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this, " wrong login details",Toast.LENGTH_LONG).show();
            }
        }
    }
}
