package com.example.trackme.tm.trackme;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class db extends SQLiteOpenHelper {
    public db(Context context) {
        super(context, "db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       String registers="Create TABLE User(name VARCHAR, code VARCHAR primary key, email VARCHAR, password VARCHAR, phone VARCHAR);";
       db.execSQL(registers);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
