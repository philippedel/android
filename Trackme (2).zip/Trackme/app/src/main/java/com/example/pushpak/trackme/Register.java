package com.example.pushpak.trackme;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {
    EditText e1,e2,e3,ps1,ps2,e4,e5;
        Button b1;
        FirebaseDatabase db;
        DatabaseReference ref;
        user user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        e1= (EditText)findViewById(R.id.e1);
        e2= (EditText)findViewById(R.id.e2);
        e3= (EditText)findViewById(R.id.e3);
        ps1= (EditText)findViewById(R.id.ps1);
        ps2= (EditText)findViewById(R.id.ps2);
        e4= (EditText)findViewById(R.id.e4);
        e5= (EditText)findViewById(R.id.e5);
        b1=(Button)findViewById(R.id.b1);
        db = FirebaseDatabase.getInstance();
        ref = db.getReference("user");
        user = new user();


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                      ref.addValueEventListener(new ValueEventListener() {
                          @Override
                          public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            getValues();
                              ref.child("user").setValue(user);
                            Toast.makeText(Register.this,"Data inserted",Toast.LENGTH_LONG).show();
                          }

                          @Override
                          public void onCancelled(@NonNull DatabaseError databaseError) {

                          }
                      });
                ps2.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        String ps = ps1.getText().toString();
                        if (s.length() > 0 && ps.length() > 0) {
                            if(!ps2 .equals(ps)){
                                Toast.makeText(Register.this,"please enter same password",Toast.LENGTH_SHORT).show();
                            }

                        }
                    }
                });
            }
        });
    }

    private void getValues(){
         user.setName(e1.getText().toString());
        user.setUsername(e2.getText().toString());
        user.setEmail(e3.getText().toString());
        user.setPassword(ps1.getText().toString());
        user.setPhone(e4.getText().toString());
        user.setCode(e5.getText().toString());

    }
}
